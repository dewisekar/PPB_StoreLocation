package com.example.ppb_storelocation;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.jakewharton.picasso.OkHttp3Downloader;
import com.squareup.picasso.Picasso;

import java.util.List;

public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.CustomViewHolder>{

    private List<Message> dataList;
    private Context context;

    public CustomAdapter(Context context, List<Message> dataList){
        this.context = context;
        this.dataList = dataList;
    }

    class CustomViewHolder extends RecyclerView.ViewHolder{
        private TextView regionName;

        CustomViewHolder(View regionItem) {
            super(regionItem);
            regionName = regionItem.findViewById(R.id.region_name);
        }

        private void setRegionItem(Message region){
            regionName.setText(region.getLatitude());
        }
    }


    @NonNull
    @Override
    public CustomAdapter.CustomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new CustomViewHolder(LayoutInflater.from(context).inflate(R.layout.custom_row, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull CustomAdapter.CustomViewHolder holder, int position) {
        holder.setRegionItem(dataList.get(position));
    }


    @Override
    public int getItemCount() {
        return dataList.size();
    }
}
